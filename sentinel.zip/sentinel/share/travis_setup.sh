#!/bin/bash
set -evx

mkdir ~/.nerocore

# safety check
if [ ! -f ~/.nerocore/.nero.conf ]; then
  cp share/nero.conf.example ~/.nerocore/nero.conf
fi
